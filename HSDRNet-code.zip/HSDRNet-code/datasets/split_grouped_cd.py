import argparse
import json
import os
import re
import shutil
from collections import defaultdict
from pathlib import Path

import cv2
import numpy as np


IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp"}


def parse_args():
    parser = argparse.ArgumentParser(
        description="Create a reproducible group-aware split for change detection datasets."
    )
    parser.add_argument(
        "--input-root",
        required=True,
        help="Directory containing A/, B/, label/ or train|val|test/A,B,label.",
    )
    parser.add_argument(
        "--output-root",
        required=True,
        help="Output directory for the new train/val/test split.",
    )
    parser.add_argument("--train-ratio", type=float, default=0.6)
    parser.add_argument("--val-ratio", type=float, default=0.2)
    parser.add_argument("--test-ratio", type=float, default=0.2)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument(
        "--mode",
        choices=["copy", "symlink"],
        default="copy",
        help="Use symlink to save disk space when the environment supports it.",
    )
    parser.add_argument(
        "--group-pattern",
        default=None,
        help=(
            "Optional regex with one capture group for original image id. "
            "Default handles names like train_638_0_1.png and img_0_512_0_512.png."
        ),
    )
    parser.add_argument(
        "--min-change-ratio",
        type=float,
        default=0.0,
        help="Drop patches whose positive label ratio is below this value.",
    )
    parser.add_argument(
        "--max-change-ratio",
        type=float,
        default=1.0,
        help="Drop patches whose positive label ratio is above this value.",
    )
    return parser.parse_args()


def default_group_id(name):
    stem = Path(name).stem

    # Coordinate patch names: area_0_512_0_512 -> area
    m = re.match(r"^(.+?)_\d+_\d+_\d+_\d+$", stem)
    if m:
        return m.group(1)

    # Common LEVIR patch names: train_638_0_1 -> train_638
    m = re.match(r"^(.+?)_\d+_\d+$", stem)
    if m:
        return m.group(1)

    return stem


def collect_split_dirs(root):
    root = Path(root)
    if (root / "A").is_dir() and (root / "B").is_dir() and (root / "label").is_dir():
        return [root]

    split_dirs = []
    for split in ("train", "val", "test"):
        split_root = root / split
        if (split_root / "A").is_dir() and (split_root / "B").is_dir() and (split_root / "label").is_dir():
            split_dirs.append(split_root)
    if not split_dirs:
        raise FileNotFoundError(
            f"{root} must contain A/B/label or train|val|test/A,B,label directories."
        )
    return split_dirs


def label_change_ratio(label_path):
    label = cv2.imread(str(label_path), cv2.IMREAD_GRAYSCALE)
    if label is None:
        raise FileNotFoundError(f"Cannot read label: {label_path}")
    return float((label > 0).mean())


def collect_items(input_root, group_pattern, min_change_ratio, max_change_ratio):
    regex = re.compile(group_pattern) if group_pattern else None
    groups = defaultdict(list)
    skipped = []

    for split_root in collect_split_dirs(input_root):
        label_dir = split_root / "label"
        for label_path in sorted(label_dir.iterdir()):
            if label_path.suffix.lower() not in IMAGE_EXTS:
                continue

            name = label_path.name
            a_path = split_root / "A" / name
            b_path = split_root / "B" / name
            if not a_path.is_file() or not b_path.is_file():
                skipped.append({"name": name, "reason": "missing A or B image"})
                continue

            change_ratio = label_change_ratio(label_path)
            if change_ratio < min_change_ratio or change_ratio > max_change_ratio:
                skipped.append({"name": name, "reason": "change ratio filter", "change_ratio": change_ratio})
                continue

            if regex:
                match = regex.search(Path(name).stem)
                group_id = match.group(1) if match else Path(name).stem
            else:
                group_id = default_group_id(name)

            groups[group_id].append(
                {
                    "name": name,
                    "A": str(a_path),
                    "B": str(b_path),
                    "label": str(label_path),
                    "change_ratio": change_ratio,
                }
            )

    if not groups:
        raise RuntimeError("No valid samples found.")
    return groups, skipped


def group_stats(items):
    patch_count = len(items)
    ratios = [item["change_ratio"] for item in items]
    return {
        "patch_count": patch_count,
        "mean_change_ratio": float(np.mean(ratios)),
        "positive_patches": int(sum(r > 0 for r in ratios)),
    }


def split_groups(groups, train_ratio, val_ratio, test_ratio, seed):
    ratio_sum = train_ratio + val_ratio + test_ratio
    if abs(ratio_sum - 1.0) > 1e-6:
        raise ValueError("train/val/test ratios must sum to 1.0")

    rng = np.random.default_rng(seed)
    group_rows = []
    for group_id, items in groups.items():
        stats = group_stats(items)
        group_rows.append((group_id, stats["patch_count"], stats["mean_change_ratio"]))

    rng.shuffle(group_rows)
    group_rows.sort(key=lambda row: row[2], reverse=True)

    total_patches = sum(row[1] for row in group_rows)
    targets = {
        "train": total_patches * train_ratio,
        "val": total_patches * val_ratio,
        "test": total_patches * test_ratio,
    }
    split_to_groups = {"train": [], "val": [], "test": []}
    split_counts = {"train": 0, "val": 0, "test": 0}

    for group_id, patch_count, _ in group_rows:
        split = min(
            split_counts,
            key=lambda name: (split_counts[name] + patch_count) / max(targets[name], 1),
        )
        split_to_groups[split].append(group_id)
        split_counts[split] += patch_count

    return split_to_groups


def ensure_output_dirs(output_root):
    for split in ("train", "val", "test"):
        for subdir in ("A", "B", "label", "list"):
            (Path(output_root) / split / subdir).mkdir(parents=True, exist_ok=True)


def place_file(src, dst, mode):
    if dst.exists():
        return
    if mode == "symlink":
        dst.symlink_to(Path(src).resolve())
    else:
        shutil.copy2(src, dst)


def materialize_split(groups, split_to_groups, output_root, mode):
    ensure_output_dirs(output_root)
    manifest = {}

    for split, group_ids in split_to_groups.items():
        names = []
        split_root = Path(output_root) / split
        for group_id in group_ids:
            for item in groups[group_id]:
                name = item["name"]
                names.append(name)
                place_file(item["A"], split_root / "A" / name, mode)
                place_file(item["B"], split_root / "B" / name, mode)
                place_file(item["label"], split_root / "label" / name, mode)

        names = sorted(names)
        with open(split_root / "list" / f"{split}.txt", "w") as f:
            for name in names:
                f.write(f"{name}\n")
        manifest[split] = names

    return manifest


def summarize(groups, split_to_groups, manifest, skipped, args):
    report = {
        "input_root": str(Path(args.input_root).resolve()),
        "output_root": str(Path(args.output_root).resolve()),
        "seed": args.seed,
        "ratios": {
            "train": args.train_ratio,
            "val": args.val_ratio,
            "test": args.test_ratio,
        },
        "mode": args.mode,
        "group_count": len(groups),
        "skipped_count": len(skipped),
        "skipped_examples": skipped[:20],
        "splits": {},
    }

    for split, group_ids in split_to_groups.items():
        items = [item for group_id in group_ids for item in groups[group_id]]
        ratios = [item["change_ratio"] for item in items]
        report["splits"][split] = {
            "group_count": len(group_ids),
            "patch_count": len(manifest[split]),
            "mean_change_ratio": float(np.mean(ratios)) if ratios else 0.0,
            "positive_patch_count": int(sum(r > 0 for r in ratios)),
            "groups": sorted(group_ids),
        }
    return report


def main():
    args = parse_args()
    groups, skipped = collect_items(
        args.input_root,
        args.group_pattern,
        args.min_change_ratio,
        args.max_change_ratio,
    )
    split_to_groups = split_groups(
        groups,
        args.train_ratio,
        args.val_ratio,
        args.test_ratio,
        args.seed,
    )
    manifest = materialize_split(groups, split_to_groups, args.output_root, args.mode)
    report = summarize(groups, split_to_groups, manifest, skipped, args)

    report_path = Path(args.output_root) / "split_report.json"
    with open(report_path, "w") as f:
        json.dump(report, f, indent=2)

    print(json.dumps({k: v for k, v in report["splits"].items()}, indent=2))
    print(f"Report saved to {report_path}")


if __name__ == "__main__":
    main()
