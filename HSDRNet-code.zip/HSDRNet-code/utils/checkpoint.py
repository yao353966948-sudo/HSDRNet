from collections import OrderedDict

import torch

CHECKPOINT_STATE_KEYS = ("state_dict", "model_state_dict", "model", "net")


def _looks_like_state_dict(value):
    return (
        isinstance(value, dict)
        and bool(value)
        and all(torch.is_tensor(v) for v in value.values())
    )


def extract_state_dict(checkpoint):
    if isinstance(checkpoint, dict):
        for key in CHECKPOINT_STATE_KEYS:
            value = checkpoint.get(key)
            if _looks_like_state_dict(value):
                return value
        if _looks_like_state_dict(checkpoint):
            return checkpoint
    raise ValueError("Input checkpoint does not look like a PyTorch state_dict.")


def align_state_dict_module_prefix(state_dict, model):
    model_keys = list(model.state_dict().keys())
    model_uses_module = bool(model_keys) and all(
        key.startswith("module.") for key in model_keys
    )
    checkpoint_keys = list(state_dict.keys())
    checkpoint_uses_module = bool(checkpoint_keys) and all(
        key.startswith("module.") for key in checkpoint_keys
    )

    if checkpoint_uses_module and not model_uses_module:
        return OrderedDict((key[7:], value) for key, value in state_dict.items())
    if model_uses_module and not checkpoint_uses_module:
        return OrderedDict(
            ("module." + key, value) for key, value in state_dict.items()
        )
    return state_dict


def load_checkpoint(model, checkpoint_path, map_location=None):
    checkpoint = torch.load(checkpoint_path, map_location=map_location)
    state_dict = extract_state_dict(checkpoint)
    state_dict = align_state_dict_module_prefix(state_dict, model)
    model.load_state_dict(state_dict, strict=True)
