import torch
import torch.nn as nn
import torch.nn.functional as F
from .decoder import HardRegionEstimationBranch
from .decoder import HSDRDecoder
from .encoder import Encoder


class HSDRNet(nn.Module):

    def __init__(self, input=3, output=1):
        super(HSDRNet, self).__init__()
        channel = 64
        self.encoder = Encoder(channel)
        self.hsdr_decoder = HSDRDecoder(channel)
        self.hard_region_branch = HardRegionEstimationBranch(channel)

    def forward(self, x):
        t1 = x[:, 0:3, :, :]
        t2 = x[:, 3:6, :, :]
        t1_p2, t1_p3, t1_p4, t1_p5 = self.encoder(t1)
        t2_p2, t2_p3, t2_p4, t2_p5 = self.encoder(t2)
        d2 = torch.abs(t1_p2 - t2_p2)
        d3 = torch.abs(t1_p3 - t2_p3)
        d4 = torch.abs(t1_p4 - t2_p4)
        d5 = torch.abs(t1_p5 - t2_p5)
        hard_region_mask, hard_region_feature = self.hard_region_branch(t1, t2, d2)
        hard_region_mask = F.interpolate(
            hard_region_mask, x.size()[2:], mode="bilinear", align_corners=True
        )
        hard_region_mask = torch.sigmoid(hard_region_mask)
        change_mask, mask_d2, mask_d3, mask_d4, mask_d5 = self.hsdr_decoder(
            d2, d3, d4, d5, hard_region_feature
        )
        change_mask = F.interpolate(
            change_mask, x.size()[2:], mode="bilinear", align_corners=True
        )
        mask_d2 = F.interpolate(
            mask_d2, x.size()[2:], mode="bilinear", align_corners=True
        )
        mask_d3 = F.interpolate(
            mask_d3, x.size()[2:], mode="bilinear", align_corners=True
        )
        mask_d4 = F.interpolate(
            mask_d4, x.size()[2:], mode="bilinear", align_corners=True
        )
        mask_d5 = F.interpolate(
            mask_d5, x.size()[2:], mode="bilinear", align_corners=True
        )
        change_mask = torch.sigmoid(change_mask)
        mask_d2 = torch.sigmoid(mask_d2)
        mask_d3 = torch.sigmoid(mask_d3)
        mask_d4 = torch.sigmoid(mask_d4)
        mask_d5 = torch.sigmoid(mask_d5)
        multi_scale_predictions = torch.cat(
            [change_mask, mask_d2, mask_d3, mask_d4, mask_d5], dim=1
        )
        return (multi_scale_predictions, hard_region_mask)


def get_model():
    model = HSDRNet(3, 1)
    return model
