import torch
import torch.nn as nn
import torch.nn.functional as F
from .encoder import FeatureFusionModule
from .hsdr import HSDR


class ChangePredictionHead(nn.Module):

    def __init__(self, channel):
        super(ChangePredictionHead, self).__init__()
        self.prediction_head = nn.Sequential(
            nn.Conv2d(channel, channel, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(channel),
            nn.ReLU(inplace=True),
            nn.Conv2d(channel, 1, kernel_size=1),
        )

    def forward(self, feature):
        mask = self.prediction_head(feature)
        return mask


class ContextEnhancementUnit(nn.Module):

    def __init__(self, in_channel, channel):
        super(ContextEnhancementUnit, self).__init__()
        self.feature_transition = nn.Sequential(
            nn.Conv2d(in_channel, in_channel, kernel_size=1),
            nn.BatchNorm2d(in_channel),
            nn.ReLU(inplace=True),
        )
        hid_channel = max(8, channel // 8)
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.channel_attention = nn.Sequential(
            nn.Linear(in_channel, hid_channel),
            nn.ReLU(inplace=True),
            nn.Linear(hid_channel, in_channel),
            nn.Sigmoid(),
        )
        self.feature_context = nn.Sequential(
            nn.Conv2d(in_channel, channel, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(channel),
            nn.ReLU(inplace=True),
        )

    def forward(self, x, mask=None):
        x = self.feature_transition(x)
        if mask is not None:
            x = x * mask + x
        b, c, _, _ = x.size()
        vec_y = self.avg_pool(x).view(b, c)
        channel_att = self.channel_attention(vec_y).view(b, c, 1, 1)
        enhanced_feature = self.feature_context(x * channel_att)
        return enhanced_feature


class CrossLayerReviewModule(nn.Module):

    def __init__(self, in_channel, channel):
        super(CrossLayerReviewModule, self).__init__()
        self.ceu_1 = ContextEnhancementUnit(in_channel, channel)
        self.ceu_2 = ContextEnhancementUnit(in_channel, channel)
        self.ceu_3 = ContextEnhancementUnit(in_channel, channel)
        self.fusion_conv = nn.Sequential(
            nn.Conv2d(channel + 1, channel, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(channel),
            nn.ReLU(inplace=True),
        )

    def forward(self, feature, fine_mask, coarse_mask):
        context_1 = self.ceu_1(feature)
        reverse_att = 1 - torch.sigmoid(coarse_mask)
        context_2 = self.ceu_2(feature, reverse_att)
        prediction_disagreement_att = (1 - torch.sigmoid(coarse_mask)) * torch.sigmoid(
            fine_mask
        ) + (1 - torch.sigmoid(fine_mask)) * torch.sigmoid(coarse_mask)
        context_3 = self.ceu_3(feature, prediction_disagreement_att)
        feature = context_1 + context_2 + context_3
        reviewed_feature = self.fusion_conv(torch.cat([feature, fine_mask], dim=1))
        return reviewed_feature


class HSDRDecoder(nn.Module):

    def __init__(self, channel):
        super(HSDRDecoder, self).__init__()
        self.change_head_d2 = ChangePredictionHead(channel)
        self.change_head_d3 = ChangePredictionHead(channel)
        self.change_head_d4 = ChangePredictionHead(channel)
        self.change_head_d5 = ChangePredictionHead(channel)
        self.cross_layer_review_d3 = CrossLayerReviewModule(channel * 2, channel)
        self.cross_layer_review_d4 = CrossLayerReviewModule(channel * 2, channel)
        self.cross_layer_review_d5 = CrossLayerReviewModule(channel * 2, channel)
        self.hsdr = HSDR(channel)
        self.change_head = ChangePredictionHead(channel)

    def forward(self, d2, d3, d4, d5, u):
        d3 = F.interpolate(d3, d2.size()[2:], mode="bilinear", align_corners=True)
        d4 = F.interpolate(d4, d2.size()[2:], mode="bilinear", align_corners=True)
        d5 = F.interpolate(d5, d2.size()[2:], mode="bilinear", align_corners=True)
        mask_d2 = self.change_head_d2(d2)
        mask_d3 = self.change_head_d3(d3)
        mask_d4 = self.change_head_d4(d4)
        mask_d5 = self.change_head_d5(d5)
        d3 = self.cross_layer_review_d3(torch.cat([d2, d3], dim=1), mask_d2, mask_d3)
        d4 = self.cross_layer_review_d4(torch.cat([d2, d4], dim=1), mask_d2, mask_d4)
        d5 = self.cross_layer_review_d5(torch.cat([d2, d5], dim=1), mask_d2, mask_d5)
        recalibrated_feature = self.hsdr(d2, u, d3, d4, d5)
        change_mask = self.change_head(recalibrated_feature)
        return (change_mask, mask_d2, mask_d3, mask_d4, mask_d5)


class HardRegionEstimationBranch(nn.Module):

    def __init__(self, channel):
        super(HardRegionEstimationBranch, self).__init__()
        self.feature_texture = nn.Sequential(
            nn.Conv2d(3, channel // 2, kernel_size=3, stride=2, padding=1),
            nn.BatchNorm2d(channel // 2),
            nn.ReLU(inplace=True),
            nn.Conv2d(channel // 2, channel, kernel_size=3, stride=2, padding=1),
            nn.BatchNorm2d(channel),
            nn.ReLU(inplace=True),
        )
        self.fam = FeatureFusionModule(channel)
        self.hard_region_head = ChangePredictionHead(channel)

    def forward(self, t1, t2, d2):
        t1_texture = self.feature_texture(t1)
        t2_texture = self.feature_texture(t2)
        hard_region_feature = torch.abs(t1_texture - t2_texture)
        hard_region_feature = self.fam(d2, hard_region_feature)
        hard_region_mask = self.hard_region_head(hard_region_feature)
        return (hard_region_mask, hard_region_feature)
