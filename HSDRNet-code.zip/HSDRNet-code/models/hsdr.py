import torch
import torch.nn as nn
import torch.nn.functional as F


class ConvBNReLU(nn.Module):

    def __init__(
        self,
        in_channels,
        out_channels,
        kernel_size=3,
        stride=1,
        padding=None,
        bias=False,
    ):
        super().__init__()
        if padding is None:
            padding = kernel_size // 2
        self.block = nn.Sequential(
            nn.Conv2d(
                in_channels, out_channels, kernel_size, stride, padding, bias=bias
            ),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
        )

    def forward(self, x):
        return self.block(x)


class ResidualPredictionRefinement(nn.Module):

    def __init__(self, channels):
        super().__init__()
        self.conv1 = ConvBNReLU(channels, channels, kernel_size=3, stride=1, padding=1)
        self.conv2 = nn.Sequential(
            nn.Conv2d(
                channels, channels, kernel_size=3, stride=1, padding=1, bias=False
            ),
            nn.BatchNorm2d(channels),
        )
        self.act = nn.ReLU(inplace=True)

    def forward(self, x):
        out = self.conv2(self.conv1(x))
        out = out + x
        out = self.act(out)
        return out


class HardAwareDetailCalibration(nn.Module):

    def __init__(self, channels):
        super().__init__()
        self.hard_gate = nn.Sequential(
            nn.Conv2d(channels, 1, kernel_size=3, stride=1, padding=1, bias=True),
            nn.Sigmoid(),
        )
        self.pre = ConvBNReLU(channels, channels, kernel_size=3, stride=1, padding=1)
        self.branch3 = ConvBNReLU(
            channels, channels, kernel_size=3, stride=1, padding=1
        )
        self.branch5 = ConvBNReLU(
            channels, channels, kernel_size=5, stride=1, padding=2
        )
        self.branch7 = ConvBNReLU(
            channels, channels, kernel_size=7, stride=1, padding=3
        )
        self.merge = nn.Sequential(
            nn.Conv2d(
                channels * 3, channels, kernel_size=1, stride=1, padding=0, bias=False
            ),
            nn.BatchNorm2d(channels),
            nn.ReLU(inplace=True),
        )

    def forward(self, d2, u):
        hard_att = self.hard_gate(u)
        x = d2 * (1.0 + hard_att)
        x = self.pre(x)
        x3 = self.branch3(x)
        x5 = self.branch5(x)
        x7 = self.branch7(x)
        xm = self.merge(torch.cat([x3, x5, x7], dim=1))
        out = x + xm
        return out


class SemanticConsensusModeling(nn.Module):

    def __init__(self, channels, num_levels=3, reduction=8):
        super().__init__()
        hidden = max(channels // reduction, 8)
        self.num_levels = num_levels
        self.proj3 = ConvBNReLU(channels, channels, kernel_size=3, stride=1, padding=1)
        self.proj4 = ConvBNReLU(channels, channels, kernel_size=3, stride=1, padding=1)
        self.proj5 = ConvBNReLU(channels, channels, kernel_size=3, stride=1, padding=1)
        self.weight_gen = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(channels, hidden, kernel_size=1, bias=False),
            nn.ReLU(inplace=True),
            nn.Conv2d(hidden, channels * num_levels, kernel_size=1, bias=False),
        )

    def forward(self, d3, d4, d5):
        d3 = self.proj3(d3)
        d4 = self.proj4(d4)
        d5 = self.proj5(d5)
        feat_sum = d3 + d4 + d5
        b, c, _, _ = feat_sum.shape
        weights = self.weight_gen(feat_sum)
        weights = weights.view(b, self.num_levels, c, 1, 1)
        weights = torch.softmax(weights, dim=1)
        feats = torch.stack([d3, d4, d5], dim=1)
        out = torch.sum(feats * weights, dim=1)
        return out


class SemanticGatedDetailInjection(nn.Module):

    def __init__(self, channels):
        super().__init__()
        self.semantic_proj = ConvBNReLU(
            channels, channels, kernel_size=1, stride=1, padding=0
        )
        self.detail_proj = ConvBNReLU(
            channels, channels, kernel_size=1, stride=1, padding=0
        )
        self.gate = nn.Sequential(
            ConvBNReLU(channels * 2, channels, kernel_size=3, stride=1, padding=1),
            nn.Conv2d(channels, 1, kernel_size=1, stride=1, padding=0, bias=True),
            nn.Sigmoid(),
        )
        self.out_proj = ConvBNReLU(
            channels, channels, kernel_size=3, stride=1, padding=1
        )

    def forward(self, detail_feat, semantic_feat):
        detail_feat = self.detail_proj(detail_feat)
        semantic_feat = self.semantic_proj(semantic_feat)
        gate = self.gate(torch.cat([semantic_feat, detail_feat], dim=1))
        fused = semantic_feat + gate * detail_feat
        fused = self.out_proj(fused)
        return fused


class HSDR(nn.Module):

    def __init__(self, channels):
        super().__init__()
        self.hdc = HardAwareDetailCalibration(channels)
        self.scm = SemanticConsensusModeling(channels, num_levels=3)
        self.sgdi = SemanticGatedDetailInjection(channels)
        self.rpr = ResidualPredictionRefinement(channels)

    def forward(self, d2, u, d3, d4, d5):
        detail_feat = self.hdc(d2, u)
        semantic_feat = self.scm(d3, d4, d5)
        fused_feat = self.sgdi(detail_feat, semantic_feat)
        out = self.rpr(fused_feat)
        return out
