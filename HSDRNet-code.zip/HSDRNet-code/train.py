import sys

sys.path.insert(0, ".")
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.backends.cudnn as cudnn
import os, time
import numpy as np
import torch.optim.lr_scheduler
from argparse import ArgumentParser
import random
import datasets.dataset as my_data_loader
import datasets.Transforms as my_transforms
from models.model import get_model
from utils.metric_tool import ConfuseMatrixMeter

RUN_SEED = 43


def default_data_root(file_root):
    if file_root == "LEVIR":
        return "./datasets/BCD/LEVIR+512"
    if file_root == "GVLM":
        return "../datasets/BCD/GVLM-512"
    if file_root == "MCD":
        return "../BCD/MCD-512"
    raise ValueError("Unknown dataset name {}".format(file_root))


def resolve_data_roots(args):
    data_root = args.data_root or default_data_root(args.file_root)
    args.train_data_root = data_root
    args.test_data_root_1 = args.test_data_root or data_root
    args.test_data_root_2 = args.test_data_root_2 or None
    args.test_name_1 = args.test_name or "{}_Test".format(args.file_root)
    args.test_name_2 = args.test_name_2 or "{}_Test_2".format(args.file_root)


def experiment_name(args):
    tag = args.exp_tag
    if not tag and args.data_root:
        tag = os.path.basename(os.path.normpath(args.data_root))
    dataset_name = args.file_root if not tag else "{}_{}".format(args.file_root, tag)
    return "{}_iter_{}_lr_{}_seed_{}".format(
        dataset_name, args.max_steps, args.lr, args.seed
    )


def label_edge_prediction(label):
    ero = 1 - F.max_pool2d(1 - label, kernel_size=5, stride=1, padding=2)
    dil = F.max_pool2d(label, kernel_size=5, stride=1, padding=2)
    edge = dil - ero
    return edge


def bce_dice_loss(pres, gts):
    bce = F.binary_cross_entropy(pres, gts)
    inter = (pres * gts).sum()
    eps = 1e-05
    dice = (2 * inter + eps) / (pres.sum() + gts.sum() + eps)
    return bce + 1 - dice


class DeepSupervisionLoss(nn.Module):

    def __init__(self):
        super(DeepSupervisionLoss, self).__init__()

    def forward(self, pres, gts):
        if isinstance(gts, tuple):
            gts = gts[0]
        b, n, h, w = pres.size()
        loss = 0
        for i in range(n):
            loss += bce_dice_loss(pres[:, i : i + 1, :, :], gts)
        return loss


@torch.no_grad()
def val(args, val_loader, model, criterion):
    model.eval()
    confusion_meter = ConfuseMatrixMeter(n_class=2)
    epoch_loss = []
    total_batches = len(val_loader)
    print(len(val_loader))
    for iter, batched_inputs in enumerate(val_loader):
        img, target = batched_inputs
        start_time = time.time()
        if args.on_gpu == True:
            img = img.cuda()
            target = target.cuda()
        img_var = torch.autograd.Variable(img).float()
        target_var = torch.autograd.Variable(target).float()
        change_mask, uncertainty_mask = model(img_var)
        pred = torch.round(change_mask[:, 0:1]).long()
        time_taken = time.time() - start_time
        loss = 0
        f1 = confusion_meter.update_cm(
            pr=pred.cpu().numpy(), gt=target_var.cpu().numpy()
        )
        if iter % 5 == 0:
            print(
                "\r[%d/%d] F1: %3f loss: %.3f time: %.3f"
                % (iter, total_batches, f1, loss, time_taken),
                end="",
            )
    average_epoch_loss_val = 0
    scores = confusion_meter.get_scores()
    return (average_epoch_loss_val, scores)


def train(
    args,
    train_loader,
    model,
    criterion,
    optimizer,
    epoch,
    max_batches,
    cur_iter=0,
    lr_factor=1.0,
):
    model.train()
    confusion_meter = ConfuseMatrixMeter(n_class=2)
    epoch_loss = []
    for iter, batched_inputs in enumerate(train_loader):
        img, target = batched_inputs
        start_time = time.time()
        if args.on_gpu == True:
            img = img.cuda()
            target = target.cuda()
        img_var = torch.autograd.Variable(img).float()
        target_var = torch.autograd.Variable(target).float()
        lr = adjust_learning_rate(
            args, optimizer, epoch, iter + cur_iter, max_batches, lr_factor=lr_factor
        )
        change_mask, uncertainty_mask = model(img_var)
        change_pre = change_mask[:, 0:1].detach()
        uncertainty_gt = torch.mul(target_var, 1.0 - change_pre) + torch.mul(
            change_pre, 1.0 - target_var
        )
        loss = criterion(change_mask, target_var) + F.binary_cross_entropy(
            uncertainty_mask, uncertainty_gt
        )
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        pred = torch.round(change_mask[:, 0:1]).long()
        epoch_loss.append(loss.data.item())
        time_taken = time.time() - start_time
        res_time = (max_batches * args.max_epochs - iter - cur_iter) * time_taken / 3600
        with torch.no_grad():
            f1 = confusion_meter.update_cm(
                pr=pred.cpu().numpy(), gt=target_var.cpu().numpy()
            )
        if iter % 5 == 0:
            print(
                "\riteration: [%d/%d] f1: %.3f lr: %.7f loss: %.3f time:%.3f h"
                % (
                    iter + cur_iter,
                    max_batches * args.max_epochs,
                    f1,
                    lr,
                    loss.data.item(),
                    res_time,
                ),
                end="",
            )
    average_epoch_loss_train = sum(epoch_loss) / len(epoch_loss)
    scores = confusion_meter.get_scores()
    return (average_epoch_loss_train, scores, lr)


def adjust_learning_rate(args, optimizer, epoch, iter, max_batches, lr_factor=1):
    if args.lr_mode == "poly":
        cur_iter = iter
        max_iter = max_batches * args.max_epochs
        lr = args.lr * (1 - cur_iter * 1.0 / max_iter) ** 0.9
    else:
        raise ValueError("Unknown lr mode {}".format(args.lr_mode))
    if epoch == 0 and iter < 200:
        lr = args.lr * 0.9 * (iter + 1) / 200 + 0.1 * args.lr
    lr *= lr_factor
    for param_group in optimizer.param_groups:
        param_group["lr"] = lr
    return lr


def train_val_change_detection(args):
    global get_model
    torch.backends.cudnn.benchmark = True
    SEED = args.seed
    torch.manual_seed(SEED)
    torch.cuda.manual_seed(SEED)
    torch.cuda.manual_seed_all(SEED)
    np.random.seed(SEED)
    random.seed(SEED)
    model = get_model()
    resolve_data_roots(args)
    args.save_dir = (
        os.path.join(args.save_dir, args.model_name, experiment_name(args)) + "/"
    )
    if not os.path.exists(args.save_dir):
        os.makedirs(args.save_dir)
    if args.on_gpu:
        model = model.cuda()
    total_params = sum([np.prod(p.size()) for p in model.parameters()])
    print("Total network parameters (excluding idr): " + str(total_params))
    mean = [0.406, 0.456, 0.485, 0.406, 0.456, 0.485]
    std = [0.225, 0.224, 0.229, 0.225, 0.224, 0.229]
    train_dataset_transform = my_transforms.Compose(
        [
            my_transforms.Normalize(mean=mean, std=std),
            my_transforms.Scale(args.in_width, args.in_height),
            my_transforms.RandomCropResize(),
            my_transforms.RandomFlip(),
            my_transforms.RandomExchange(),
            my_transforms.ToTensor(),
        ]
    )
    val_dataset_transform = my_transforms.Compose(
        [
            my_transforms.Normalize(mean=mean, std=std),
            my_transforms.Scale(args.in_width, args.in_height),
            my_transforms.ToTensor(),
        ]
    )
    train_data = my_data_loader.Dataset(
        "train", file_root=args.train_data_root, transform=train_dataset_transform
    )
    train_loader = torch.utils.data.DataLoader(
        train_data,
        batch_size=args.batch_size,
        shuffle=True,
        num_workers=args.num_workers,
        pin_memory=False,
        drop_last=True,
    )
    val_data = my_data_loader.Dataset(
        "val", file_root=args.train_data_root, transform=val_dataset_transform
    )
    val_loader = torch.utils.data.DataLoader(
        val_data,
        shuffle=False,
        batch_size=args.batch_size,
        num_workers=args.num_workers,
        pin_memory=False,
    )
    test_data_1 = my_data_loader.Dataset(
        "test", file_root=args.test_data_root_1, transform=val_dataset_transform
    )
    test_loader_1 = torch.utils.data.DataLoader(
        test_data_1,
        shuffle=False,
        batch_size=args.batch_size,
        num_workers=args.num_workers,
        pin_memory=False,
    )
    test_loader_2 = None
    if args.test_data_root_2:
        test_data_2 = my_data_loader.Dataset(
            "test", file_root=args.test_data_root_2, transform=val_dataset_transform
        )
        test_loader_2 = torch.utils.data.DataLoader(
            test_data_2,
            shuffle=False,
            batch_size=args.batch_size,
            num_workers=args.num_workers,
            pin_memory=False,
        )
    max_batches = len(train_loader)
    print("For each epoch, we have {} batches".format(max_batches))
    if args.on_gpu:
        cudnn.benchmark = True
    args.max_epochs = int(np.ceil(args.max_steps / max_batches))
    start_epoch = 0
    cur_iter = 0
    max_f1_val = 0
    log_file_path = args.save_dir + args.log_file
    if os.path.isfile(log_file_path):
        logger = open(log_file_path, "a")
    else:
        logger = open(log_file_path, "w")
        logger.write("Parameters: %s" % str(total_params))
        logger.write(
            "\n%s\t%s\t%s\t%s\t%s\t%s"
            % ("Epoch", "Kappa (val)", "IoU (val)", "F1 (val)", "R (val)", "P (val)")
        )
    logger.flush()
    optimizer = torch.optim.AdamW(
        model.parameters(), lr=args.lr, betas=(0.9, 0.99), weight_decay=0.01
    )
    model_file_name = args.save_dir + "best_model.pth"
    criterion = DeepSupervisionLoss()
    for epoch in range(start_epoch, args.max_epochs):
        loss_train, score_tr, lr = train(
            args,
            train_loader,
            model,
            criterion,
            optimizer,
            epoch,
            max_batches,
            cur_iter,
        )
        cur_iter += len(train_loader)
        torch.cuda.empty_cache()
        if epoch == 0:
            continue
        loss_val, score_val = val(args, val_loader, model, criterion)
        torch.cuda.empty_cache()
        logger.write(
            "\n%d\t\t%.4f\t\t%.4f\t\t%.4f\t\t%.4f\t\t%.4f"
            % (
                epoch,
                score_val["Kappa"],
                score_val["IoU"],
                score_val["F1"],
                score_val["recall"],
                score_val["precision"],
            )
        )
        logger.flush()
        if epoch % 1 == 0 and max_f1_val <= score_val["F1"]:
            max_f1_val = score_val["F1"]
            torch.save(model.state_dict(), model_file_name)
        print("Epoch " + str(epoch) + ": Details")
        print(
            "\nEpoch No. %d:\tTrain Loss = %.4f\tVal Loss = %.4f\t F1(tr) = %.4f\t F1(val) = %.4f"
            % (epoch, loss_train, loss_val, score_tr["F1"], score_val["F1"])
        )
    state_dict = torch.load(model_file_name)
    model.load_state_dict(state_dict)
    loss_test_set1, score_test_set1 = val(args, test_loader_1, model, criterion)
    torch.cuda.empty_cache()
    print(
        "\n%s :\t Kappa (te) = %.4f\t IoU (te) = %.4f\t F1 (te) = %.4f\t R (te) = %.4f\t P (te) = %.4f"
        % (
            args.test_name_1,
            score_test_set1["Kappa"],
            score_test_set1["IoU"],
            score_test_set1["F1"],
            score_test_set1["recall"],
            score_test_set1["precision"],
        )
    )
    logger.write(
        "\n%s\t\t%.4f\t\t%.4f\t\t%.4f\t\t%.4f\t\t%.4f"
        % (
            args.test_name_1,
            score_test_set1["Kappa"],
            score_test_set1["IoU"],
            score_test_set1["F1"],
            score_test_set1["recall"],
            score_test_set1["precision"],
        )
    )
    logger.flush()
    if test_loader_2 is not None:
        loss_test_set2, score_test_set2 = val(args, test_loader_2, model, criterion)
        torch.cuda.empty_cache()
        print(
            "\n%s :\t Kappa (te) = %.4f\t IoU (te) = %.4f\t F1 (te) = %.4f\t R (te) = %.4f\t P (te) = %.4f"
            % (
                args.test_name_2,
                score_test_set2["Kappa"],
                score_test_set2["IoU"],
                score_test_set2["F1"],
                score_test_set2["recall"],
                score_test_set2["precision"],
            )
        )
        logger.write(
            "\n%s\t\t%.4f\t\t%.4f\t\t%.4f\t\t%.4f\t\t%.4f"
            % (
                args.test_name_2,
                score_test_set2["Kappa"],
                score_test_set2["IoU"],
                score_test_set2["F1"],
                score_test_set2["recall"],
                score_test_set2["precision"],
            )
        )
        logger.flush()
    logger.close()


if __name__ == "__main__":
    parser = ArgumentParser()
    parser.add_argument("--seed", type=int, default=RUN_SEED, help="Seed")
    parser.add_argument("--model_name", default="HSDRNet", help="Model name")
    parser.add_argument("--file_root", default="LEVIR", help="Dataset name")
    parser.add_argument(
        "--data_root",
        default="",
        help="Root with train/val/test folders; overrides file_root default path",
    )
    parser.add_argument(
        "--exp_tag",
        default="",
        help="Extra name inserted into the experiment directory",
    )
    parser.add_argument(
        "--test_data_root",
        default="./datasets/BCD/LEVIR+512",
        help="Optional root used for the first test set",
    )
    parser.add_argument(
        "--test_data_root_2",
        default="./datasets/BCD/BCDD-512",
        help="Optional root used for a second test set",
    )
    parser.add_argument(
        "--test_name", default="", help="Name written for the first test result"
    )
    parser.add_argument(
        "--test_name_2", default="", help="Name written for the second test result"
    )
    parser.add_argument("--in_width", type=int, default=512, help="Width of RGB image")
    parser.add_argument(
        "--in_height", type=int, default=512, help="Height of RGB image"
    )
    parser.add_argument(
        "--max_steps", type=int, default=5000, help="Max. number of iterations"
    )
    parser.add_argument(
        "--num_workers", type=int, default=4, help="No. of parallel threads"
    )
    parser.add_argument("--batch_size", type=int, default=16, help="Batch size")
    parser.add_argument(
        "--lr", type=float, default=0.0005, help="Initial learning rate"
    )
    parser.add_argument("--lr_mode", default="poly", help="Learning rate policy")
    parser.add_argument(
        "--save_dir", default="./weights/", help="Directory to save the results"
    )
    parser.add_argument(
        "--log_file",
        default="trainValLog.txt",
        help="File that stores the training and validation logs",
    )
    parser.add_argument(
        "--on_gpu",
        default=True,
        type=lambda x: str(x).lower() == "true",
        help="Run on CPU or GPU",
    )
    parser.add_argument(
        "--weight",
        default="",
        type=str,
        help="pretrained weight, can be a non-strict copy",
    )
    args = parser.parse_args()
    print("Called with args:")
    print(args)
    train_val_change_detection(args)
