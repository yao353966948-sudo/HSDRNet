import os
import sys
from argparse import ArgumentParser
import torch

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, PROJECT_ROOT)
from models.model import get_model
from utils.checkpoint import load_checkpoint


def main():
    parser = ArgumentParser(
        description="Run HSDRNet checkpoint and output-structure sanity checks."
    )
    parser.add_argument(
        "--checkpoint",
        default="",
        help="Optional checkpoint to strict-load before the forward pass.",
    )
    args = parser.parse_args()
    model = get_model()
    model.eval()
    if args.checkpoint:
        load_checkpoint(model, args.checkpoint, map_location="cpu")
        print("Loaded checkpoint")
    total_params = sum((p.numel() for p in model.parameters()))
    dummy_input = torch.randn(1, 6, 512, 512)
    with torch.no_grad():
        outputs = model(dummy_input)
    print("Model:", model.__class__.__name__)
    print("Parameter count:", total_params)
    print("Output type:", type(outputs).__name__)
    if not isinstance(outputs, tuple) or len(outputs) != 2:
        raise RuntimeError(
            "Expected unchanged output structure: tuple(multi_scale_predictions, hard_region_map)."
        )
    multi_scale_predictions, hard_region_map = outputs
    print("multi_scale_predictions:", tuple(multi_scale_predictions.shape))
    print("hard_region_map:", tuple(hard_region_map.shape))
    expected_main = (1, 5, 512, 512)
    expected_hard_region = (1, 1, 512, 512)
    if tuple(multi_scale_predictions.shape) != expected_main:
        raise RuntimeError(
            "Unexpected multi_scale_predictions shape: {}".format(
                tuple(multi_scale_predictions.shape)
            )
        )
    if tuple(hard_region_map.shape) != expected_hard_region:
        raise RuntimeError(
            "Unexpected hard_region_map shape: {}".format(tuple(hard_region_map.shape))
        )
    print("Output structure check: passed")


if __name__ == "__main__":
    main()
