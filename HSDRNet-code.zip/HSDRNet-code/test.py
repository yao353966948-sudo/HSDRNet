import sys

sys.path.insert(0, ".")
import torch
import scipy.io as scio
import torch.backends.cudnn as cudnn
import torch.optim.lr_scheduler
import datasets.dataset as my_data_loader
import datasets.Transforms as my_transforms
from utils.metric_tool import ConfuseMatrixMeter
from PIL import Image
import os, time
import numpy as np
from argparse import ArgumentParser
from models.model import get_model

RUN_SEED = 48


def default_data_root(file_root):
    if file_root == "LEVIR":
        return "./datasets/BCD/LEVIR+512"
    if file_root == "GVLM":
        return "../datasets/BCD/GVLM-512"
    if file_root == "MCD":
        return "../BCD/MCD-512"
    raise ValueError("Unknown dataset name {}".format(file_root))


def resolve_data_roots(args):
    data_root = args.data_root or default_data_root(args.file_root)
    args.test_data_root_1 = args.test_data_root or data_root
    args.test_data_root_2 = args.test_data_root_2 or None
    args.test_name_1 = args.test_name or "{}_Test".format(args.file_root)
    args.test_name_2 = args.test_name_2 or "{}_Test_2".format(args.file_root)
    args.vis_dir_1 = (
        args.vis_dir
        or "./predict/"
        + args.model_name
        + "/"
        + args.file_root
        + f"/{args.test_name_1}_seed{args.seed}/"
    )
    args.vis_dir_2 = (
        args.vis_dir_2
        or "./predict/"
        + args.model_name
        + "/"
        + args.file_root
        + f"/{args.test_name_2}_seed{args.seed}/"
    )


def experiment_name(args):
    tag = args.exp_tag
    if not tag and args.data_root:
        tag = os.path.basename(os.path.normpath(args.data_root))
    dataset_name = args.file_root if not tag else "{}_{}".format(args.file_root, tag)
    return "{}_iter_{}_lr_{}_seed_{}".format(
        dataset_name, args.max_steps, args.lr, args.seed
    )


@torch.no_grad()
def val(args, val_loader, model, vis_dir):
    model.eval()
    confusion_meter = ConfuseMatrixMeter(n_class=2)
    total_batches = len(val_loader)
    print(len(val_loader))
    for iter, batched_inputs in enumerate(val_loader):
        img, target = batched_inputs
        start_time = time.time()
        if args.on_gpu == True:
            img = img.cuda()
            target = target.cuda()
        img_var = torch.autograd.Variable(img).float()
        target_var = torch.autograd.Variable(target).float()
        change_mask, uncertainty_mask = model(img_var)
        output = change_mask[:, 0:1]
        pred = torch.where(
            output > 0.5, torch.ones_like(output), torch.zeros_like(output)
        ).long()
        time_taken = time.time() - start_time
        pred_np = pred.cpu().numpy()
        gt_np = target_var.cpu().numpy()
        for batch_idx in range(pred_np.shape[0]):
            file_idx = iter * val_loader.batch_size + batch_idx
            if file_idx >= len(val_loader.sampler.data_source.file_list):
                continue
            img_name = val_loader.sampler.data_source.file_list[file_idx]
            pr = pred_np[batch_idx, 0]
            gt = gt_np[batch_idx, 0]
            index_tp = np.where(np.logical_and(pr == 1, gt == 1))
            index_fp = np.where(np.logical_and(pr == 1, gt == 0))
            index_tn = np.where(np.logical_and(pr == 0, gt == 0))
            index_fn = np.where(np.logical_and(pr == 0, gt == 1))
            map = np.zeros((gt.shape[0], gt.shape[1], 3), dtype=np.uint8)
            map[index_tp] = [255, 255, 255]
            map[index_fp] = [255, 0, 0]
            map[index_tn] = [0, 0, 0]
            map[index_fn] = [0, 0, 255]
            change_map = Image.fromarray(np.array(map, dtype=np.uint8))
            save_name = os.path.basename(img_name)
            change_map.save(os.path.join(vis_dir, save_name))
        f1 = confusion_meter.update_cm(pred_np, gt_np)
        if iter % 5 == 0:
            print(
                "\r[%d/%d] F1: %3f time: %.3f" % (iter, total_batches, f1, time_taken),
                end="",
            )
    scores = confusion_meter.get_scores()
    return scores


def val_change_detection(args):
    torch.backends.cudnn.benchmark = True
    SEED = args.seed
    torch.manual_seed(SEED)
    torch.cuda.manual_seed(SEED)
    torch.cuda.manual_seed_all(SEED)
    np.random.seed(SEED)
    model = get_model()
    resolve_data_roots(args)
    args.save_dir = (
        os.path.join(args.save_dir, args.model_name, experiment_name(args)) + "/"
    )
    if not os.path.exists(args.save_dir):
        os.makedirs(args.save_dir)
    if not os.path.exists(args.vis_dir_1):
        os.makedirs(args.vis_dir_1)
    if args.test_data_root_2 and (not os.path.exists(args.vis_dir_2)):
        os.makedirs(args.vis_dir_2)
    if args.on_gpu:
        model = model.cuda()
    total_params = sum([np.prod(p.size()) for p in model.parameters()])
    print("Total network parameters (excluding idr): " + str(total_params))
    mean = [0.406, 0.456, 0.485, 0.406, 0.456, 0.485]
    std = [0.225, 0.224, 0.229, 0.225, 0.224, 0.229]
    val_dataset_transform = my_transforms.Compose(
        [
            my_transforms.Normalize(mean=mean, std=std),
            my_transforms.Scale(args.in_width, args.in_height),
            my_transforms.ToTensor(),
        ]
    )
    test_data_1 = my_data_loader.Dataset(
        "test", file_root=args.test_data_root_1, transform=val_dataset_transform
    )
    test_loader_1 = torch.utils.data.DataLoader(
        test_data_1,
        shuffle=False,
        batch_size=args.batch_size,
        num_workers=args.num_workers,
        pin_memory=False,
    )
    test_loader_2 = None
    if args.test_data_root_2:
        test_data_2 = my_data_loader.Dataset(
            "test", file_root=args.test_data_root_2, transform=val_dataset_transform
        )
        test_loader_2 = torch.utils.data.DataLoader(
            test_data_2,
            shuffle=False,
            batch_size=args.batch_size,
            num_workers=args.num_workers,
            pin_memory=False,
        )
    if args.on_gpu:
        cudnn.benchmark = True
    log_file_path = args.save_dir + args.log_file
    if os.path.isfile(log_file_path):
        logger = open(log_file_path, "a")
    else:
        logger = open(log_file_path, "w")
        logger.write("Parameters: %s" % str(total_params))
        logger.write(
            "\n%s\t%s\t%s\t%s\t%s\t%s" % ("Epoch", "Kappa", "IoU", "F1", "R", "P")
        )
    logger.flush()
    model_file_name = args.save_dir + "best_model.pth"
    state_dict = torch.load(model_file_name)
    model.load_state_dict(state_dict)
    score_test_1 = val(args, test_loader_1, model, args.vis_dir_1)
    torch.cuda.empty_cache()
    print(
        "\n%s :\t Kappa (te) = %.4f\t IoU (te) = %.4f\t F1 (te) = %.4f\t R (te) = %.4f\t P (te) = %.4f"
        % (
            args.test_name_1,
            score_test_1["Kappa"],
            score_test_1["IoU"],
            score_test_1["F1"],
            score_test_1["recall"],
            score_test_1["precision"],
        )
    )
    logger.write(
        "\n%s\t\t%.4f\t\t%.4f\t\t%.4f\t\t%.4f\t\t%.4f"
        % (
            args.test_name_1,
            score_test_1["Kappa"],
            score_test_1["IoU"],
            score_test_1["F1"],
            score_test_1["recall"],
            score_test_1["precision"],
        )
    )
    logger.flush()
    scio.savemat(os.path.join(args.vis_dir_1, "results.mat"), score_test_1)
    if test_loader_2 is not None:
        score_test_2 = val(args, test_loader_2, model, args.vis_dir_2)
        torch.cuda.empty_cache()
        print(
            "\n%s :\t Kappa (te) = %.4f\t IoU (te) = %.4f\t F1 (te) = %.4f\t R (te) = %.4f\t P (te) = %.4f"
            % (
                args.test_name_2,
                score_test_2["Kappa"],
                score_test_2["IoU"],
                score_test_2["F1"],
                score_test_2["recall"],
                score_test_2["precision"],
            )
        )
        logger.write(
            "\n%s\t\t%.4f\t\t%.4f\t\t%.4f\t\t%.4f\t\t%.4f"
            % (
                args.test_name_2,
                score_test_2["Kappa"],
                score_test_2["IoU"],
                score_test_2["F1"],
                score_test_2["recall"],
                score_test_2["precision"],
            )
        )
        logger.flush()
        scio.savemat(os.path.join(args.vis_dir_2, "results.mat"), score_test_2)
    logger.close()


if __name__ == "__main__":
    parser = ArgumentParser()
    parser.add_argument("--seed", type=int, default=RUN_SEED, help="Seed")
    parser.add_argument("--model_name", default="HSDRNet", help="Model name")
    parser.add_argument("--file_root", default="LEVIR", help="Dataset name")
    parser.add_argument(
        "--data_root",
        default="",
        help="Root with train/val/test folders; overrides file_root default path",
    )
    parser.add_argument(
        "--exp_tag",
        default="",
        help="Extra name inserted into the experiment directory",
    )
    parser.add_argument(
        "--test_data_root",
        default="./datasets/BCD/LEVIR+512",
        help="Optional root used for the first test set",
    )
    parser.add_argument(
        "--test_data_root_2",
        default="./datasets/BCD/BCDD-512",
        help="Optional root used for a second test set",
    )
    parser.add_argument(
        "--test_name",
        default="LEVIR_Test",
        help="Name written for the first test result",
    )
    parser.add_argument(
        "--test_name_2",
        default="BCDD_Test",
        help="Name written for the second test result",
    )
    parser.add_argument(
        "--vis_dir", default="", help="Directory for first test visualizations"
    )
    parser.add_argument(
        "--vis_dir_2", default="", help="Directory for second test visualizations"
    )
    parser.add_argument("--in_width", type=int, default=512, help="Width of RGB image")
    parser.add_argument(
        "--in_height", type=int, default=512, help="Height of RGB image"
    )
    parser.add_argument(
        "--max_steps", type=int, default=5000, help="Max. number of iterations"
    )
    parser.add_argument(
        "--num_workers", type=int, default=4, help="No. of parallel threads"
    )
    parser.add_argument("--batch_size", type=int, default=1, help="Batch size")
    parser.add_argument(
        "--lr", type=float, default=0.0005, help="Initial learning rate"
    )
    parser.add_argument("--lr_mode", default="poly", help="Learning rate policy")
    parser.add_argument(
        "--save_dir", default="./weights/", help="Directory to save the results"
    )
    parser.add_argument(
        "--log_file", default="Test.txt", help="File that stores the testing logs"
    )
    parser.add_argument(
        "--on_gpu",
        default=True,
        type=lambda x: str(x).lower() == "true",
        help="Run on CPU or GPU",
    )
    parser.add_argument(
        "--weight",
        default="",
        type=str,
        help="pretrained weight, can be a non-strict copy",
    )
    args = parser.parse_args()
    print("Called with args:")
    print(args)
    val_change_detection(args)
